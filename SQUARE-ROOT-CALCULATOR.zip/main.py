## FIRST GET THE INPUT STATEMENT
number = int(input("enter a number: "))

## NOW THE FORMULA (CODE)
sqrt = number ** 0.5

## NOW THE OUTPUT STATEMENT
print("square root:", sqrt)